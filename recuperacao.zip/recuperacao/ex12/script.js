// Geovanna Clara 
document.getElementById("myForm").addEventListener("submit", function(event){
    event.preventDefault(); 
  
    Swal.fire({
      icon: 'success',
      title: 'Envio com sucesso!',
      showConfirmButton: false,
      timer: 1500
    });
  });
  