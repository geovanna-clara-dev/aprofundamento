// Geovanna Clara
const fileInput = document.getElementById('fileInput');
const form = document.getElementById('uploadForm');
const preview = document.querySelector('.preview');

fileInput.addEventListener('change', function() {
  preview.innerHTML = '';
  const files = Array.from(fileInput.files);
  files.forEach(file => {
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = function(e) {
        const img = document.createElement('img');
        img.src = e.target.result;
        preview.appendChild(img);
      };
      reader.readAsDataURL(file);
    } else {
      const p = document.createElement('p');
      p.textContent = `${file.name} - ${file.type}`;
      preview.appendChild(p);
    }
  });
});

form.addEventListener('submit', function(e) {
  e.preventDefault();
  const formData = new FormData(form);
  formData.getAll('fileInput').forEach(file => {
    console.log('Arquivo enviado:', file.name);
    // Aqui você pode adicionar lógica para enviar o arquivo para o servidor
  });
});
