// Geovanna Clara
document.getElementById('navbarToggler').addEventListener('click', function() {
    document.getElementById('navbarMenu').classList.toggle('active');
});