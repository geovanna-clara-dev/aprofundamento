// Geovanna clara
function highlightItem(event) {
   
    let items = document.querySelectorAll('#itemList li');
    items.forEach(item => {
      item.classList.remove('highlighted');
    });
  
    
    let selectedItem = event.target;
    selectedItem.classList.add('highlighted');
  }
  
 
  let items = document.querySelectorAll('#itemList li');
  items.forEach(item => {
    item.addEventListener('click', highlightItem);
  });
  