// Geovanna Clara
document.getElementById('reservationForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;

    if (date && time) {
        const messageDiv = document.getElementById('message');
        messageDiv.textContent = `Reserva confirmada para ${date} às ${time}.`;
        messageDiv.style.color = 'green';
    } else {
        alert('Por favor, selecione uma data e hora.');
    }
});
