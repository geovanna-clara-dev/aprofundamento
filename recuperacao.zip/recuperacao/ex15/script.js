// Geovanna Clara
function contarPalavras() {
    let texto = document.getElementById('texto').value;
    let palavras = texto.trim().split(/\s+/);
    document.getElementById('contador').textContent = palavras.length;
}

document.getElementById('texto').addEventListener('input', contarPalavras);
