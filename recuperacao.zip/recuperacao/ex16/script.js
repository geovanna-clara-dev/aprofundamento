// Geovanna Clara
const taskInput = document.getElementById('taskInput');
const addTaskBtn = document.getElementById('addTaskBtn');
const taskList = document.getElementById('taskList');

const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
tasks.forEach(task => addTaskToList(task));

function addTaskToList(taskText) {
    const li = document.createElement('li');
    li.innerHTML = `
        <input type="checkbox">
        <span>${taskText}</span>
        <button class="removeBtn">Remover</button>
    `;
    taskList.appendChild(li);
}

addTaskBtn.addEventListener('click', () => {
    const taskText = taskInput.value.trim();
    if (taskText !== '') {
        addTaskToList(taskText);
        tasks.push(taskText);
        localStorage.setItem('tasks', JSON.stringify(tasks));
        taskInput.value = '';
    }
});

taskList.addEventListener('click', (event) => {
    if (event.target.classList.contains('removeBtn')) {
        const li = event.target.parentElement;
        const taskText = li.querySelector('span').textContent;
        const taskIndex = tasks.indexOf(taskText);
        if (taskIndex !== -1) {
            tasks.splice(taskIndex, 1);
            localStorage.setItem('tasks', JSON.stringify(tasks));
            li.remove();
        }
    }
});

tasks.forEach(task => addTaskToList(task));
